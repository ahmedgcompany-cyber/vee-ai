import { useState } from 'react';
import { 
  X, Users, Download, DollarSign, TrendingUp, Package,
  BarChart3, Activity, Clock,
  Search, MoreVertical, Edit, Trash2, Eye
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { products, sampleUsers, analytics } from '@/data';
import Avatar from '@/components/Avatar';

interface AdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AdminDashboard({ isOpen, onClose }: AdminDashboardProps) {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'users' | 'uploads' | 'analytics'>('overview');
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen || !user || user.role !== 'admin') return null;

  const tabs = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'products', label: 'Products', icon: Package },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'uploads', label: 'Pending Uploads', icon: Clock },
    { id: 'analytics', label: 'Analytics', icon: Activity },
  ];

  const filteredProducts = products.filter(p => 
    p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredUsers = sampleUsers.filter(u => 
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-nexus-bg/95 backdrop-blur-xl"
        onClick={onClose}
      />
      
      {/* Dashboard Panel */}
      <div className="relative w-full max-w-7xl max-h-[90vh] bg-nexus-bg-secondary rounded-3xl border border-nexus-border/30 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-nexus-border/20">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-nexus-accent/20 border border-nexus-accent/30 flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-nexus-accent" />
            </div>
            <div>
              <h2 className="font-heading text-xl font-semibold text-nexus-text">Admin Dashboard</h2>
              <p className="text-nexus-text-secondary text-sm">Manage your platform</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="px-3 py-1 rounded-full bg-nexus-accent/10 text-nexus-accent text-sm">
              Admin Access
            </span>
            <button 
              onClick={onClose}
              className="w-10 h-10 rounded-full bg-nexus-bg border border-nexus-border/30 flex items-center justify-center text-nexus-text-secondary hover:text-nexus-accent transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden flex">
          {/* Sidebar */}
          <div className="w-64 border-r border-nexus-border/20 p-4 hidden md:block">
            <nav className="space-y-1">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all ${
                      activeTab === tab.id
                        ? 'bg-nexus-accent/10 text-nexus-accent border border-nexus-accent/30'
                        : 'text-nexus-text-secondary hover:bg-nexus-bg hover:text-nexus-text'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    {tab.label}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {/* Overview Tab */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <h3 className="font-heading text-2xl font-semibold text-nexus-text">Platform Overview</h3>
                
                {/* Key Metrics */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  {[
                    { label: 'Total Revenue', value: `$${analytics.totalRevenue.toLocaleString()}`, icon: DollarSign, change: '+24%' },
                    { label: 'Total Downloads', value: analytics.totalDownloads.toLocaleString(), icon: Download, change: '+18%' },
                    { label: 'Total Users', value: analytics.totalUsers.toLocaleString(), icon: Users, change: '+32%' },
                    { label: 'Active Subs', value: analytics.activeSubscriptions.toLocaleString(), icon: TrendingUp, change: '+15%' },
                  ].map((stat, i) => {
                    const Icon = stat.icon;
                    return (
                      <div key={i} className="p-4 rounded-2xl bg-nexus-bg border border-nexus-border/20">
                        <div className="w-10 h-10 rounded-xl bg-nexus-accent/10 flex items-center justify-center mb-3">
                          <Icon className="w-5 h-5 text-nexus-accent" />
                        </div>
                        <p className="text-nexus-text-secondary text-sm">{stat.label}</p>
                        <p className="font-heading text-2xl font-bold text-nexus-text">{stat.value}</p>
                        <span className="text-green-400 text-xs">{stat.change} this month</span>
                      </div>
                    );
                  })}
                </div>

                {/* Popular Products */}
                <div className="p-6 rounded-2xl bg-nexus-bg border border-nexus-border/20">
                  <h4 className="font-heading font-semibold text-nexus-text mb-4">Popular Products</h4>
                  <div className="space-y-3">
                    {analytics.popularProducts.map((product, i) => (
                      <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-nexus-bg-secondary">
                        <div className="flex items-center gap-3">
                          <span className="w-6 h-6 rounded-full bg-nexus-accent/20 text-nexus-accent text-xs flex items-center justify-center font-medium">
                            {i + 1}
                          </span>
                          <span className="text-nexus-text font-medium">{product.productName}</span>
                        </div>
                        <div className="flex items-center gap-6 text-sm">
                          <span className="text-nexus-text-secondary">{product.downloads.toLocaleString()} downloads</span>
                          <span className="text-nexus-accent font-medium">${product.revenue.toLocaleString()}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Monthly Growth Chart */}
                <div className="p-6 rounded-2xl bg-nexus-bg border border-nexus-border/20">
                  <h4 className="font-heading font-semibold text-nexus-text mb-4">Monthly Growth</h4>
                  <div className="flex items-end justify-between h-48 gap-4">
                    {analytics.monthlyGrowth.map((month, i) => (
                      <div key={i} className="flex-1 flex flex-col items-center gap-2">
                        <div className="w-full flex flex-col gap-1">
                          <div 
                            className="w-full bg-nexus-accent/30 rounded-t-lg transition-all hover:bg-nexus-accent/50"
                            style={{ height: `${(month.revenue / 30000) * 100}px` }}
                          />
                          <div 
                            className="w-full bg-nexus-accent/60 rounded-t-lg transition-all hover:bg-nexus-accent/80"
                            style={{ height: `${(month.downloads / 25000) * 100}px` }}
                          />
                        </div>
                        <span className="text-nexus-text-secondary text-xs">{month.month}</span>
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center justify-center gap-6 mt-4">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded bg-nexus-accent/60" />
                      <span className="text-nexus-text-secondary text-xs">Downloads</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded bg-nexus-accent/30" />
                      <span className="text-nexus-text-secondary text-xs">Revenue</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Products Tab */}
            {activeTab === 'products' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="font-heading text-2xl font-semibold text-nexus-text">Products</h3>
                  <button className="px-4 py-2 rounded-lg bg-nexus-accent text-nexus-bg text-sm font-medium hover:shadow-glow transition-all">
                    + Add Product
                  </button>
                </div>

                {/* Search */}
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-nexus-text-secondary" />
                  <input
                    type="text"
                    placeholder="Search products..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-11 pr-4 py-3 rounded-xl bg-nexus-bg border border-nexus-border/30 text-nexus-text placeholder:text-nexus-text-secondary/50 focus:outline-none focus:border-nexus-accent/50 transition-colors"
                  />
                </div>

                {/* Products Table */}
                <div className="space-y-3">
                  {filteredProducts.map((product) => (
                    <div key={product.id} className="flex items-center justify-between p-4 rounded-2xl bg-nexus-bg border border-nexus-border/20">
                      <div className="flex items-center gap-4">
                        <img 
                          src={product.images[0]} 
                          alt={product.title}
                          className="w-12 h-12 rounded-xl object-cover"
                        />
                        <div>
                          <p className="text-nexus-text font-medium">{product.title}</p>
                          <p className="text-nexus-text-secondary text-sm capitalize">{product.category} • {product.type}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-6">
                        <div className="text-right">
                          <p className="text-nexus-text font-medium">{product.downloads.toLocaleString()}</p>
                          <p className="text-nexus-text-secondary text-xs">downloads</p>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-yellow-500">★</span>
                          <span className="text-nexus-text">{product.rating}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <button className="w-8 h-8 rounded-lg bg-nexus-bg-secondary flex items-center justify-center text-nexus-text-secondary hover:text-nexus-accent transition-colors">
                            <Eye className="w-4 h-4" />
                          </button>
                          <button className="w-8 h-8 rounded-lg bg-nexus-bg-secondary flex items-center justify-center text-nexus-text-secondary hover:text-nexus-accent transition-colors">
                            <Edit className="w-4 h-4" />
                          </button>
                          <button className="w-8 h-8 rounded-lg bg-nexus-bg-secondary flex items-center justify-center text-nexus-text-secondary hover:text-red-400 transition-colors">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Users Tab */}
            {activeTab === 'users' && (
              <div className="space-y-6">
                <h3 className="font-heading text-2xl font-semibold text-nexus-text">Users</h3>

                {/* Search */}
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-nexus-text-secondary" />
                  <input
                    type="text"
                    placeholder="Search users..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-11 pr-4 py-3 rounded-xl bg-nexus-bg border border-nexus-border/30 text-nexus-text placeholder:text-nexus-text-secondary/50 focus:outline-none focus:border-nexus-accent/50 transition-colors"
                  />
                </div>

                {/* Users Table */}
                <div className="space-y-3">
                  {filteredUsers.map((u) => (
                    <div key={u.id} className="flex items-center justify-between p-4 rounded-2xl bg-nexus-bg border border-nexus-border/20">
                      <div className="flex items-center gap-4">
                        <Avatar name={u.name} avatarUrl={u.avatar} size="md" />
                        <div>
                          <p className="text-nexus-text font-medium">{u.name}</p>
                          <p className="text-nexus-text-secondary text-sm">{u.email}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-6">
                        <span className={`px-3 py-1 rounded-full text-xs capitalize ${
                          u.role === 'admin' ? 'bg-nexus-accent/20 text-nexus-accent' :
                          u.role === 'premium' ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-nexus-bg-secondary text-nexus-text-secondary'
                        }`}>
                          {u.role}
                        </span>
                        <span className="text-nexus-text-secondary text-sm">
                          {new Date(u.createdAt).toLocaleDateString()}
                        </span>
                        <button className="w-8 h-8 rounded-lg bg-nexus-bg-secondary flex items-center justify-center text-nexus-text-secondary hover:text-nexus-accent transition-colors">
                          <MoreVertical className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Pending Uploads Tab */}
            {activeTab === 'uploads' && (
              <div className="space-y-6">
                <h3 className="font-heading text-2xl font-semibold text-nexus-text">Pending Uploads</h3>
                
                <div className="text-center py-12">
                  <Clock className="w-16 h-16 text-nexus-border/50 mx-auto mb-4" />
                  <p className="text-nexus-text-secondary">No pending uploads</p>
                  <p className="text-nexus-text-secondary text-sm mt-2">New user submissions will appear here</p>
                </div>
              </div>
            )}

            {/* Analytics Tab */}
            {activeTab === 'analytics' && (
              <div className="space-y-6">
                <h3 className="font-heading text-2xl font-semibold text-nexus-text">Detailed Analytics</h3>
                
                {/* User Activity */}
                <div className="p-6 rounded-2xl bg-nexus-bg border border-nexus-border/20">
                  <h4 className="font-heading font-semibold text-nexus-text mb-4">User Activity (Last 30 Days)</h4>
                  <div className="space-y-3">
                    {analytics.userActivity?.map((day, i) => (
                      <div key={i} className="flex items-center gap-4">
                        <span className="text-nexus-text-secondary text-sm w-20">{day.date}</span>
                        <div className="flex-1 flex items-center gap-2">
                          <div 
                            className="h-4 bg-nexus-accent/60 rounded-full"
                            style={{ width: `${(day.active / 2000) * 100}%` }}
                          />
                          <span className="text-nexus-text text-sm">{day.active}</span>
                        </div>
                        <span className="text-green-400 text-sm">+{day.new} new</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
