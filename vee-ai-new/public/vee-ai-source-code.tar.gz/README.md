# 🚀 VEE.ai - Creator Platform

A complete platform for creators to share AI agents, apps, games, and digital experiences.

**Engineered by AHMED M T ALGHOUL**

---

## 🌐 Live Demo
**https://d4jvagowgtbra.ok.kimi.link** (Temporary)

---

## ✨ Features

### For Visitors
- 🎨 Browse projects with search & filter
- 📱 View product details and screenshots
- 🛒 Add items to cart
- 📧 Contact creators

### For Users
- 📊 **Dashboard** - Track downloads, purchases, subscriptions
- ⬆️ **Upload System** - Submit apps, games, AI agents, blogs, videos
- ❤️ **Favorites** - Save interesting projects
- 👤 **Profile Management** - Update avatar, view stats

### For Admins
- 📈 **Analytics Dashboard** - Revenue, downloads, user growth
- 📝 **Product Management** - Add/edit/remove products
- 👥 **User Management** - View and manage users
- ✅ **Upload Review** - Approve/reject user submissions

---

## 🛠 Tech Stack

### Frontend
- ⚛️ React + TypeScript
- ⚡ Vite (Build tool)
- 🎨 Tailwind CSS
- 🎬 GSAP (Animations)
- 🧩 shadcn/ui (Components)
- 🔣 Lucide React (Icons)

### Backend
- 🟢 Node.js + Express
- 🐘 PostgreSQL (Drizzle ORM)
- ☁️ AWS S3 (File Storage)
- 💳 Stripe (Payments)
- 📧 SendGrid (Email)
- 🔐 JWT (Authentication)

---

## 📁 Project Structure

```
vee-ai/
├── app/                      # Frontend React App
│   ├── src/
│   │   ├── components/       # Reusable components
│   │   ├── sections/         # Page sections
│   │   ├── hooks/            # Custom React hooks
│   │   ├── lib/              # API utilities
│   │   ├── data/             # Mock data
│   │   ├── types/            # TypeScript types
│   │   └── App.tsx           # Main app
│   ├── package.json
│   └── vite.config.ts
│
├── vee-ai-backend/           # Backend API
│   ├── src/
│   │   ├── routes/           # API routes
│   │   ├── middleware/       # Auth middleware
│   │   ├── models/           # Database schema
│   │   ├── utils/            # Utilities
│   │   └── server.ts         # Entry point
│   ├── package.json
│   └── railway.json          # Railway config
│
├── SETUP_GUIDE.md            # Complete deployment guide
└── README.md                 # This file
```

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- Git
- Accounts: GitHub, Vercel, Railway, Supabase, AWS, Stripe, SendGrid

### 1. Clone & Setup

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/vee-ai.git
cd vee-ai

# Install frontend dependencies
cd app
npm install

# Install backend dependencies
cd ../vee-ai-backend
npm install
```

### 2. Environment Variables

**Frontend** (`app/.env`):
```
VITE_API_URL=http://localhost:3001
```

**Backend** (`vee-ai-backend/.env`):
```
NODE_ENV=development
PORT=3001
FRONTEND_URL=http://localhost:5173
DATABASE_URL=postgresql://...
JWT_SECRET=your-secret
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
AWS_REGION=us-east-1
S3_BUCKET=vee-ai-uploads
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
SENDGRID_API_KEY=SG.xxx
FROM_EMAIL=noreply@vee.ai
```

### 3. Run Locally

```bash
# Terminal 1: Start backend
cd vee-ai-backend
npm run dev

# Terminal 2: Start frontend
cd app
npm run dev
```

Visit: http://localhost:5173

---

## 🌐 Deployment (FREE Forever!)

### Step 1: Push to GitHub
```bash
git add .
git commit -m "Initial commit"
git push origin main
```

### Step 2: Deploy Frontend (Vercel)
1. Go to https://vercel.com
2. Import your GitHub repo
3. Framework: Vite
4. Root Directory: `app`
5. Deploy!

### Step 3: Deploy Backend (Railway)
1. Go to https://railway.app
2. New Project → Deploy from GitHub
3. Add environment variables
4. Deploy!

### Step 4: Database (Supabase)
1. Go to https://supabase.com
2. Create new project
3. Copy connection string
4. Run migrations

### Step 5: File Storage (AWS S3)
1. Create S3 bucket
2. Create IAM user
3. Add credentials to Railway

### Step 6: Payments (Stripe)
1. Get API keys
2. Configure webhook
3. Add to Railway

### Step 7: Email (SendGrid)
1. Create API key
2. Verify sender email
3. Add to Railway

**📖 Detailed instructions in [SETUP_GUIDE.md](SETUP_GUIDE.md)**

---

## 💰 Cost Breakdown

| Service | Monthly Cost |
|---------|-------------|
| Vercel (Frontend) | **$0** |
| Railway (Backend) | **$0** |
| Supabase (Database) | **$0** |
| AWS S3 (Storage) | **~$1-5** |
| Stripe (Payments) | **2.9% + 30¢/tx** |
| SendGrid (Email) | **$0** |
| Domain (Optional) | **~$1** |

**Total: $2-7/month for a fully functional platform!**

---

## 📊 API Endpoints

### Auth
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login
- `GET /api/auth/me` - Get current user
- `PATCH /api/auth/profile` - Update profile

### Products
- `GET /api/products` - List products
- `GET /api/products/:id` - Get single product
- `POST /api/products` - Create product
- `PATCH /api/products/:id` - Update product
- `DELETE /api/products/:id` - Delete product
- `POST /api/products/:id/reviews` - Add review
- `POST /api/products/:id/favorite` - Toggle favorite

### Uploads
- `POST /api/uploads/presigned-url` - Get upload URL
- `POST /api/uploads/download-url` - Get download URL

### Payments
- `POST /api/payments/create-payment-intent` - Create payment
- `POST /api/payments/create-subscription` - Create subscription
- `POST /api/payments/webhook` - Stripe webhook

### Admin
- `GET /api/admin/analytics` - Platform analytics
- `GET /api/admin/users` - List users
- `GET /api/admin/pending-products` - Pending uploads

---

## 🔐 Environment Variables

### Required for Backend
```
NODE_ENV=production
PORT=3001
FRONTEND_URL=https://your-frontend-url
DATABASE_URL=postgresql://...
JWT_SECRET=random-string
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
AWS_REGION=us-east-1
S3_BUCKET=vee-ai-uploads
STRIPE_SECRET_KEY=sk_...
STRIPE_PUBLISHABLE_KEY=pk_...
STRIPE_WEBHOOK_SECRET=whsec_...
SENDGRID_API_KEY=SG.xxx
FROM_EMAIL=noreply@vee.ai
```

### Required for Frontend
```
VITE_API_URL=https://your-backend-url
```

---

## 🎯 Roadmap

### Phase 1: Core (Complete)
- [x] Landing page with animations
- [x] Project showcase
- [x] User dashboard
- [x] Admin dashboard
- [x] Upload system
- [x] Authentication

### Phase 2: Backend (Complete)
- [x] Express.js API
- [x] PostgreSQL database
- [x] JWT authentication
- [x] AWS S3 integration
- [x] Stripe payments
- [x] SendGrid email

### Phase 3: Features (Planned)
- [ ] Real-time notifications
- [ ] Advanced analytics
- [ ] API for developers
- [ ] Mobile app
- [ ] Community features (comments, forums)
- [ ] Affiliate program

---

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing`)
5. Open a Pull Request

---

## 📄 License

MIT License - feel free to use for your own projects!

---

## 📞 Support

- **Email**: ahmed@vee.ai
- **GitHub Issues**: Create an issue in this repo
- **Documentation**: See [SETUP_GUIDE.md](SETUP_GUIDE.md)

---

## 🙏 Acknowledgments

- Design inspired by modern SaaS platforms
- Built with love and caffeine ☕

---

**Built with ❤️ by AHMED M T ALGHOUL**

⭐ Star this repo if you find it helpful!
