# VEE.ai - Complete Deployment Guide

## 🌐 Live Website
**https://d4jvagowgtbra.ok.kimi.link**

## 👨‍💻 Engineered By
**AHMED M T ALGHOUL**

---

## 📋 Table of Contents
1. [Current Features](#current-features)
2. [How to Use the Platform](#how-to-use-the-platform)
3. [Making It Fully Functional](#making-it-fully-functional)
4. [Deployment Options](#deployment-options)
5. [Backend Setup Guide](#backend-setup-guide)
6. [Payment Integration](#payment-integration)
7. [File Storage Setup](#file-storage-setup)
8. [Database Setup](#database-setup)
9. [Domain & SSL](#domain--ssl)
10. [Maintenance & Updates](#maintenance--updates)

---

## ✅ Current Features

### Frontend (Working Now)
- ✅ **Landing Page** with animated hero section
- ✅ **Project Showcase** with search & filter
- ✅ **User Dashboard** - View downloads, purchases, subscriptions, favorites
- ✅ **Admin Dashboard** - Analytics, user management, product management
- ✅ **Upload System** - Multi-step upload for apps, games, AI agents, blogs, videos
- ✅ **Authentication System** - Login/logout with role-based access
- ✅ **Cart System** - Add to cart, view total
- ✅ **Responsive Design** - Works on mobile & desktop
- ✅ **Dark Theme** with neon accents

### Backend (Needs Setup)
- 🔄 **User Authentication** - Currently mock data
- 🔄 **File Storage** - Needs AWS S3 or similar
- 🔄 **Payment Processing** - Needs Stripe integration
- 🔄 **Database** - Needs PostgreSQL
- 🔄 **Email Service** - Needs SendGrid/AWS SES

---

## 🚀 How to Use the Platform

### As a Visitor
1. Browse the project grid (search & filter available)
2. View product details
3. Add items to cart
4. Contact the creator

### As a User (Logged In)
1. Click your avatar → **Dashboard**
2. View your downloads, purchases, subscriptions
3. Click **Upload** to submit your work
4. Track your favorites

### As an Admin
1. Click the **Admin Panel** button (bottom right)
2. View platform analytics
3. Manage products and users
4. Review pending uploads

---

## 🔧 Making It Fully Functional

### Step 1: Set Up Backend Server

#### Option A: Node.js/Express (Recommended for Beginners)

```bash
# Create backend folder
mkdir vee-ai-backend
cd vee-ai-backend
npm init -y

# Install dependencies
npm install express cors dotenv bcryptjs jsonwebtoken multer stripe pg nodemailer
npm install -D nodemon typescript @types/express @types/cors @types/bcryptjs @types/jsonwebtoken @types/multer @types/pg @types/nodemailer

# Create server.js
```

**server.js:**
```javascript
const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const multer = require('multer');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

 dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// Database connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Auth middleware
const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
};

// Routes will go here

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
```

#### Option B: Serverless (Vercel/Railway/Render)

Use platforms like:
- **Railway** (easiest): https://railway.app
- **Render**: https://render.com
- **Vercel**: https://vercel.com (for serverless functions)

---

### Step 2: Set Up Database (PostgreSQL)

#### Option A: Supabase (Free Tier - Recommended)

1. Go to https://supabase.com
2. Create a new project
3. Get your connection string from Settings → Database
4. Add to `.env`:
```
DATABASE_URL=postgresql://postgres:[password]@db.[project].supabase.co:5432/postgres
```

#### Option B: Railway PostgreSQL

1. Go to https://railway.app
2. New Project → Add PostgreSQL
3. Copy the connection string

#### Database Schema

```sql
-- Users table
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(255) NOT NULL,
  avatar_url TEXT,
  role VARCHAR(20) DEFAULT 'free',
  created_at TIMESTAMP DEFAULT NOW()
);

-- Products table
CREATE TABLE products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title VARCHAR(255) NOT NULL,
  description TEXT,
  short_description TEXT,
  category VARCHAR(50),
  type VARCHAR(20),
  price DECIMAL(10,2),
  subscription_monthly DECIMAL(10,2),
  subscription_yearly DECIMAL(10,2),
  trial_days INTEGER,
  images TEXT[],
  video_url TEXT,
  features TEXT[],
  tech_stack TEXT[],
  version VARCHAR(20),
  downloads INTEGER DEFAULT 0,
  rating DECIMAL(2,1) DEFAULT 5.0,
  tags TEXT[],
  file_size VARCHAR(20),
  file_url TEXT,
  author_id UUID REFERENCES users(id),
  status VARCHAR(20) DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Purchases table
CREATE TABLE purchases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  product_id UUID REFERENCES products(id),
  price DECIMAL(10,2),
  status VARCHAR(20) DEFAULT 'completed',
  created_at TIMESTAMP DEFAULT NOW()
);

-- Subscriptions table
CREATE TABLE subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  plan_id VARCHAR(50),
  plan_name VARCHAR(100),
  status VARCHAR(20),
  start_date TIMESTAMP,
  end_date TIMESTAMP,
  price DECIMAL(10,2),
  interval VARCHAR(20)
);

-- Downloads table
CREATE TABLE downloads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  product_id UUID REFERENCES products(id),
  version VARCHAR(20),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Reviews table
CREATE TABLE reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  product_id UUID REFERENCES products(id),
  rating INTEGER,
  comment TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
```

---

### Step 3: Set Up File Storage (AWS S3)

#### AWS S3 Setup

1. **Create AWS Account**: https://aws.amazon.com
2. **Create S3 Bucket**:
   - Bucket name: `vee-ai-uploads`
   - Region: Choose closest to your users
   - Uncheck "Block all public access" (for public files)
3. **Create IAM User**:
   - Go to IAM → Users → Create User
   - Attach policy: `AmazonS3FullAccess`
   - Save Access Key ID and Secret Access Key

4. **Install AWS SDK**:
```bash
npm install aws-sdk @aws-sdk/client-s3 @aws-sdk/s3-request-presigner
```

5. **Upload Route**:
```javascript
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');

const s3Client = new S3Client({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

// Generate presigned URL for upload
app.post('/api/upload-url', authMiddleware, async (req, res) => {
  const { filename, contentType } = req.body;
  
  const command = new PutObjectCommand({
    Bucket: process.env.S3_BUCKET,
    Key: `uploads/${req.user.id}/${Date.now()}-${filename}`,
    ContentType: contentType,
  });
  
  const url = await getSignedUrl(s3Client, command, { expiresIn: 3600 });
  res.json({ url, key: command.input.Key });
});
```

#### Alternative: Cloudflare R2 (Cheaper)

https://www.cloudflare.com/developer-platform/r2/

---

### Step 4: Stripe Payment Integration

1. **Create Stripe Account**: https://stripe.com
2. **Get API Keys** from Dashboard
3. **Add to .env**:
```
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
```

4. **Install Stripe**:
```bash
npm install stripe
```

5. **Payment Routes**:
```javascript
// Create payment intent
app.post('/api/create-payment-intent', authMiddleware, async (req, res) => {
  const { amount, productId } = req.body;
  
  const paymentIntent = await stripe.paymentIntents.create({
    amount: amount * 100, // Convert to cents
    currency: 'usd',
    metadata: { productId, userId: req.user.id },
  });
  
  res.json({ clientSecret: paymentIntent.client_secret });
});

// Create subscription
app.post('/api/create-subscription', authMiddleware, async (req, res) => {
  const { priceId } = req.body;
  
  const subscription = await stripe.subscriptions.create({
    customer: req.user.stripeCustomerId,
    items: [{ price: priceId }],
    payment_behavior: 'default_incomplete',
    expand: ['latest_invoice.payment_intent'],
  });
  
  res.json({
    subscriptionId: subscription.id,
    clientSecret: subscription.latest_invoice.payment_intent.client_secret,
  });
});

// Webhook for payment events
app.post('/api/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  
  try {
    const event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
    
    if (event.type === 'payment_intent.succeeded') {
      // Handle successful payment
      const paymentIntent = event.data.object;
      // Update database, grant access, send email
    }
    
    res.json({ received: true });
  } catch (err) {
    res.status(400).send(`Webhook Error: ${err.message}`);
  }
});
```

---

### Step 5: Email Service (SendGrid)

1. **Create SendGrid Account**: https://sendgrid.com
2. **Get API Key**
3. **Add to .env**:
```
SENDGRID_API_KEY=SG.xxx
FROM_EMAIL=noreply@vee.ai
```

4. **Email Function**:
```javascript
const sgMail = require('@sendgrid/mail');
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

const sendEmail = async (to, subject, html) => {
  await sgMail.send({
    to,
    from: process.env.FROM_EMAIL,
    subject,
    html,
  });
};
```

---

## 🌐 Deployment Options

### Option 1: Vercel (Frontend + Serverless Backend)

**Best for**: Quick deployment, automatic scaling

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy frontend
cd /mnt/okcomputer/output/app
vercel --prod

# For backend, create api/ folder in your project
```

### Option 2: Railway (Full Stack)

**Best for**: Full backend + database in one place

1. Push code to GitHub
2. Connect Railway to your repo
3. Add PostgreSQL addon
4. Deploy

### Option 3: AWS (Production Scale)

**Best for**: Enterprise, full control

- **Frontend**: S3 + CloudFront
- **Backend**: EC2 or ECS
- **Database**: RDS PostgreSQL
- **File Storage**: S3

---

## 🔐 Domain & SSL

### Buy Domain

Recommended registrars:
- **Namecheap**: https://namecheap.com
- **Cloudflare**: https://cloudflare.com
- **Google Domains**: https://domains.google

### Connect Domain to Vercel

1. Buy domain: `vee.ai` or `getvee.ai`
2. In Vercel dashboard: Project → Settings → Domains
3. Add your domain
4. Update DNS records at your registrar

### SSL Certificate

- **Vercel**: Automatic (Let's Encrypt)
- **AWS**: Use AWS Certificate Manager
- **Cloudflare**: Automatic

---

## 📊 Environment Variables (.env)

Create `.env` file:

```env
# Database
DATABASE_URL=postgresql://...

# JWT
JWT_SECRET=your-super-secret-jwt-key-change-this

# AWS S3
AWS_ACCESS_KEY_ID=AKIA...
AWS_SECRET_ACCESS_KEY=...
AWS_REGION=us-east-1
S3_BUCKET=vee-ai-uploads

# Stripe
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

# SendGrid
SENDGRID_API_KEY=SG.xxx
FROM_EMAIL=noreply@vee.ai

# Frontend URL
FRONTEND_URL=https://vee.ai
```

---

## 🔄 Maintenance & Updates

### Regular Tasks

1. **Monitor Analytics**: Check admin dashboard weekly
2. **Review Uploads**: Approve/reject user submissions
3. **Update Dependencies**: `npm update` monthly
4. **Backup Database**: Weekly automated backups
5. **Monitor Costs**: AWS/Stripe dashboards

### Scaling

When you hit growth:
1. **CDN**: Add Cloudflare for global speed
2. **Caching**: Redis for session storage
3. **Monitoring**: Sentry for error tracking
4. **Analytics**: Google Analytics or Mixpanel

---

## 💰 Cost Estimates

### Startup (Free - $50/month)
- Vercel: Free tier
- Supabase: Free tier
- AWS S3: ~$5/month
- Stripe: 2.9% + 30¢ per transaction
- SendGrid: Free tier (100 emails/day)

### Growth ($50 - $200/month)
- Vercel Pro: $20/month
- Supabase Pro: $25/month
- AWS S3: $20-50/month
- Stripe: Transaction fees only

### Scale ($200+/month)
- Custom infrastructure
- Dedicated database
- CDN
- Monitoring tools

---

## 🆘 Troubleshooting

### Common Issues

1. **CORS Errors**: Add proper CORS headers
2. **File Upload Fails**: Check S3 bucket permissions
3. **Payments Not Working**: Verify Stripe webhook URL
4. **Database Connection**: Check connection string format

### Support Resources

- **Discord**: Join Vercel/Supabase communities
- **Stack Overflow**: Tag your questions
- **Documentation**: 
  - https://stripe.com/docs
  - https://docs.aws.amazon.com/s3
  - https://supabase.com/docs

---

## 📞 Contact

For questions or custom development:
- **Email**: ahmed@vee.ai
- **GitHub**: Your GitHub profile
- **LinkedIn**: Your LinkedIn profile

---

## 🎉 Success Checklist

- [ ] Backend server deployed
- [ ] Database connected
- [ ] S3 bucket configured
- [ ] Stripe payments working
- [ ] Email service active
- [ ] Custom domain connected
- [ ] SSL certificate installed
- [ ] Admin panel accessible
- [ ] User uploads working
- [ ] Payment flow tested

---

**Built with ❤️ by AHMED M T ALGHOUL**
