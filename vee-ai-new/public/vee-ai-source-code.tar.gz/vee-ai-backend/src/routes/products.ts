import { Router } from 'express';
import { eq, desc, and, like, or } from 'drizzle-orm';
import { db } from '../utils/db';
import { products, reviews, favorites, downloads } from '../models/schema';
import { authMiddleware, AuthRequest } from '../middleware/auth';

const router = Router();

// Get all products (with filters)
router.get('/', async (req, res) => {
  try {
    const { 
      category, 
      type, 
      search, 
      sort = 'newest',
      page = '1',
      limit = '20'
    } = req.query;

    const pageNum = parseInt(page as string);
    const limitNum = parseInt(limit as string);
    const offset = (pageNum - 1) * limitNum;

    // Build query
    let query = db.query.products.findMany({
      where: and(
        eq(products.status, 'published'),
        category ? eq(products.category, category as any) : undefined,
        type ? eq(products.type, type as any) : undefined,
        search ? or(
          like(products.title, `%${search}%`),
          like(products.description, `%${search}%`)
        ) : undefined
      ),
      with: {
        author: {
          columns: {
            id: true,
            name: true,
            avatarUrl: true
          }
        }
      },
      limit: limitNum,
      offset
    });

    const allProducts = await query;

    // Get total count for pagination
    const countResult = await db.select({ count: db.fn.count() }).from(products)
      .where(and(
        eq(products.status, 'published'),
        category ? eq(products.category, category as any) : undefined,
        type ? eq(products.type, type as any) : undefined
      ));

    const total = Number(countResult[0]?.count || 0);

    res.json({
      products: allProducts,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        pages: Math.ceil(total / limitNum)
      }
    });
  } catch (error) {
    console.error('Get products error:', error);
    res.status(500).json({ error: 'Failed to get products' });
  }
});

// Get single product
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const product = await db.query.products.findFirst({
      where: eq(products.id, id),
      with: {
        author: {
          columns: {
            id: true,
            name: true,
            avatarUrl: true
          }
        },
        reviews: {
          with: {
            user: {
              columns: {
                id: true,
                name: true,
                avatarUrl: true
              }
            }
          }
        }
      }
    });

    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    res.json(product);
  } catch (error) {
    console.error('Get product error:', error);
    res.status(500).json({ error: 'Failed to get product' });
  }
});

// Create product (authenticated)
router.post('/', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const {
      title,
      description,
      shortDescription,
      category,
      type,
      price,
      subscriptionMonthly,
      subscriptionYearly,
      trialDays,
      images,
      videoUrl,
      features,
      techStack,
      tags,
      version,
      fileSize,
      fileUrl
    } = req.body;

    const [product] = await db.insert(products).values({
      title,
      description,
      shortDescription,
      category,
      type,
      price: price ? price.toString() : null,
      subscriptionMonthly: subscriptionMonthly ? subscriptionMonthly.toString() : null,
      subscriptionYearly: subscriptionYearly ? subscriptionYearly.toString() : null,
      trialDays,
      images,
      videoUrl,
      features,
      techStack,
      tags,
      version,
      fileSize,
      fileUrl,
      authorId: req.user!.id,
      status: 'pending'
    }).returning();

    res.status(201).json({
      message: 'Product created successfully',
      product
    });
  } catch (error) {
    console.error('Create product error:', error);
    res.status(500).json({ error: 'Failed to create product' });
  }
});

// Update product (owner or admin)
router.patch('/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    // Check ownership
    const product = await db.query.products.findFirst({
      where: eq(products.id, id)
    });

    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    if (product.authorId !== req.user!.id && req.user!.role !== 'admin') {
      return res.status(403).json({ error: 'Not authorized' });
    }

    const [updated] = await db.update(products)
      .set({
        ...req.body,
        updatedAt: new Date()
      })
      .where(eq(products.id, id))
      .returning();

    res.json({
      message: 'Product updated',
      product: updated
    });
  } catch (error) {
    console.error('Update product error:', error);
    res.status(500).json({ error: 'Failed to update product' });
  }
});

// Delete product
router.delete('/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    const product = await db.query.products.findFirst({
      where: eq(products.id, id)
    });

    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    if (product.authorId !== req.user!.id && req.user!.role !== 'admin') {
      return res.status(403).json({ error: 'Not authorized' });
    }

    await db.delete(products).where(eq(products.id, id));

    res.json({ message: 'Product deleted' });
  } catch (error) {
    console.error('Delete product error:', error);
    res.status(500).json({ error: 'Failed to delete product' });
  }
});

// Add review
router.post('/:id/reviews', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { rating, comment } = req.body;

    const [review] = await db.insert(reviews).values({
      userId: req.user!.id,
      productId: id,
      rating,
      comment
    }).returning();

    res.status(201).json({
      message: 'Review added',
      review
    });
  } catch (error) {
    console.error('Add review error:', error);
    res.status(500).json({ error: 'Failed to add review' });
  }
});

// Toggle favorite
router.post('/:id/favorite', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    // Check if already favorited
    const existing = await db.query.favorites.findFirst({
      where: and(
        eq(favorites.userId, req.user!.id),
        eq(favorites.productId, id)
      )
    });

    if (existing) {
      // Remove favorite
      await db.delete(favorites)
        .where(eq(favorites.id, existing.id));
      res.json({ message: 'Removed from favorites', favorited: false });
    } else {
      // Add favorite
      await db.insert(favorites).values({
        userId: req.user!.id,
        productId: id
      });
      res.json({ message: 'Added to favorites', favorited: true });
    }
  } catch (error) {
    console.error('Toggle favorite error:', error);
    res.status(500).json({ error: 'Failed to toggle favorite' });
  }
});

// Record download
router.post('/:id/download', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { version } = req.body;

    // Record download
    await db.insert(downloads).values({
      userId: req.user!.id,
      productId: id,
      version
    });

    // Increment download count
    await db.update(products)
      .set({ downloads: db.fn.increment(products.downloads) })
      .where(eq(products.id, id));

    res.json({ message: 'Download recorded' });
  } catch (error) {
    console.error('Download error:', error);
    res.status(500).json({ error: 'Failed to record download' });
  }
});

export { router as productsRouter };
