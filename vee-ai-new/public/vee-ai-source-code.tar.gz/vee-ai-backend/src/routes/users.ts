import { Router } from 'express';
import { eq, desc } from 'drizzle-orm';
import { db } from '../utils/db';
import { downloads, favorites, purchases, subscriptions } from '../models/schema';
import { authMiddleware, AuthRequest } from '../middleware/auth';

const router = Router();

// Get user's downloads
router.get('/downloads', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userDownloads = await db.query.downloads.findMany({
      where: eq(downloads.userId, req.user!.id),
      with: {
        product: {
          columns: {
            id: true,
            title: true,
            images: true,
            fileUrl: true
          }
        }
      },
      orderBy: (downloads, { desc }) => [desc(downloads.createdAt)]
    });

    res.json(userDownloads);
  } catch (error) {
    console.error('Get downloads error:', error);
    res.status(500).json({ error: 'Failed to get downloads' });
  }
});

// Get user's favorites
router.get('/favorites', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userFavorites = await db.query.favorites.findMany({
      where: eq(favorites.userId, req.user!.id),
      with: {
        product: {
          columns: {
            id: true,
            title: true,
            shortDescription: true,
            images: true,
            rating: true,
            downloads: true,
            price: true,
            type: true
          }
        }
      },
      orderBy: (favorites, { desc }) => [desc(favorites.createdAt)]
    });

    res.json(userFavorites);
  } catch (error) {
    console.error('Get favorites error:', error);
    res.status(500).json({ error: 'Failed to get favorites' });
  }
});

// Get user stats
router.get('/stats', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const [downloadsCount, favoritesCount, purchasesCount, subscriptionsCount] = await Promise.all([
      db.select({ count: db.fn.count() }).from(downloads).where(eq(downloads.userId, req.user!.id)),
      db.select({ count: db.fn.count() }).from(favorites).where(eq(favorites.userId, req.user!.id)),
      db.select({ count: db.fn.count() }).from(purchases).where(eq(purchases.userId, req.user!.id)),
      db.select({ count: db.fn.count() }).from(subscriptions).where(eq(subscriptions.userId, req.user!.id))
    ]);

    res.json({
      downloads: Number(downloadsCount[0]?.count || 0),
      favorites: Number(favoritesCount[0]?.count || 0),
      purchases: Number(purchasesCount[0]?.count || 0),
      subscriptions: Number(subscriptionsCount[0]?.count || 0)
    });
  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({ error: 'Failed to get stats' });
  }
});

export { router as usersRouter };
