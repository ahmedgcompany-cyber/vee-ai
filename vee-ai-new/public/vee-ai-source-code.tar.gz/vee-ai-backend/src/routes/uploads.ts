import { Router } from 'express';
import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { authMiddleware, AuthRequest } from '../middleware/auth';

const router = Router();

// Initialize S3 client
const s3Client = new S3Client({
  region: process.env.AWS_REGION || 'us-east-1',
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID || '',
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || ''
  }
});

const BUCKET_NAME = process.env.S3_BUCKET || 'vee-ai-uploads';

// Generate presigned URL for upload
router.post('/presigned-url', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { filename, contentType, folder = 'uploads' } = req.body;

    if (!filename || !contentType) {
      return res.status(400).json({ error: 'Filename and contentType are required' });
    }

    const key = `${folder}/${req.user!.id}/${Date.now()}-${filename}`;

    const command = new PutObjectCommand({
      Bucket: BUCKET_NAME,
      Key: key,
      ContentType: contentType,
    });

    const url = await getSignedUrl(s3Client, command, { expiresIn: 3600 });

    res.json({
      uploadUrl: url,
      fileUrl: `https://${BUCKET_NAME}.s3.${process.env.AWS_REGION}.amazonaws.com/${key}`,
      key
    });
  } catch (error) {
    console.error('Presigned URL error:', error);
    res.status(500).json({ error: 'Failed to generate upload URL' });
  }
});

// Generate download URL
router.post('/download-url', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { key } = req.body;

    if (!key) {
      return res.status(400).json({ error: 'Key is required' });
    }

    const command = new GetObjectCommand({
      Bucket: BUCKET_NAME,
      Key: key,
    });

    const url = await getSignedUrl(s3Client, command, { expiresIn: 300 }); // 5 minutes

    res.json({ downloadUrl: url });
  } catch (error) {
    console.error('Download URL error:', error);
    res.status(500).json({ error: 'Failed to generate download URL' });
  }
});

// Get multiple upload URLs (for batch uploads)
router.post('/batch-presigned-urls', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { files, folder = 'uploads' } = req.body;

    if (!Array.isArray(files) || files.length === 0) {
      return res.status(400).json({ error: 'Files array is required' });
    }

    const urls = await Promise.all(
      files.map(async (file: { filename: string; contentType: string }) => {
        const key = `${folder}/${req.user!.id}/${Date.now()}-${file.filename}`;
        
        const command = new PutObjectCommand({
          Bucket: BUCKET_NAME,
          Key: key,
          ContentType: file.contentType,
        });

        const uploadUrl = await getSignedUrl(s3Client, command, { expiresIn: 3600 });

        return {
          filename: file.filename,
          uploadUrl,
          fileUrl: `https://${BUCKET_NAME}.s3.${process.env.AWS_REGION}.amazonaws.com/${key}`,
          key
        };
      })
    );

    res.json({ urls });
  } catch (error) {
    console.error('Batch presigned URLs error:', error);
    res.status(500).json({ error: 'Failed to generate upload URLs' });
  }
});

// Delete file from S3
router.delete('/:key', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { key } = req.params;

    // Decode the key (it comes URL-encoded)
    const decodedKey = decodeURIComponent(key);

    const command = new PutObjectCommand({
      Bucket: BUCKET_NAME,
      Key: decodedKey,
    });

    await s3Client.send(command);

    res.json({ message: 'File deleted' });
  } catch (error) {
    console.error('Delete file error:', error);
    res.status(500).json({ error: 'Failed to delete file' });
  }
});

export { router as uploadsRouter };
