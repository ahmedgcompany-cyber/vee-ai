import { Router } from 'express';
import { eq, desc, sql } from 'drizzle-orm';
import { db } from '../utils/db';
import { products, users, purchases, subscriptions, downloads } from '../models/schema';
import { authMiddleware, adminMiddleware, AuthRequest } from '../middleware/auth';

const router = Router();

// All routes require admin access
router.use(authMiddleware, adminMiddleware);

// Get platform analytics
router.get('/analytics', async (req, res) => {
  try {
    // Get counts
    const [usersCount, productsCount, purchasesCount, downloadsCount] = await Promise.all([
      db.select({ count: db.fn.count() }).from(users),
      db.select({ count: db.fn.count() }).from(products).where(eq(products.status, 'published')),
      db.select({ count: db.fn.count() }).from(purchases),
      db.select({ count: db.fn.count() }).from(downloads)
    ]);

    // Get total revenue
    const revenueResult = await db.select({ 
      total: sql`SUM(${purchases.price})` 
    }).from(purchases);

    // Get active subscriptions count
    const activeSubsResult = await db.select({ 
      count: db.fn.count() 
    }).from(subscriptions).where(eq(subscriptions.status, 'active'));

    // Get popular products
    const popularProducts = await db.query.products.findMany({
      where: eq(products.status, 'published'),
      orderBy: (products, { desc }) => [desc(products.downloads)],
      limit: 5,
      columns: {
        id: true,
        title: true,
        downloads: true,
        rating: true
      }
    });

    // Get recent users
    const recentUsers = await db.query.users.findMany({
      orderBy: (users, { desc }) => [desc(users.createdAt)],
      limit: 5,
      columns: {
        id: true,
        name: true,
        email: true,
        role: true,
        createdAt: true
      }
    });

    // Get monthly growth (simplified - in production, you'd aggregate properly)
    const monthlyGrowth = [
      { month: 'Jan', revenue: 8200, downloads: 5200, users: 2100 },
      { month: 'Feb', revenue: 12400, downloads: 7800, users: 3400 },
      { month: 'Mar', revenue: 28150, downloads: 23840, users: 6950 }
    ];

    res.json({
      overview: {
        totalUsers: Number(usersCount[0]?.count || 0),
        totalProducts: Number(productsCount[0]?.count || 0),
        totalDownloads: Number(downloadsCount[0]?.count || 0),
        totalRevenue: Number(revenueResult[0]?.total || 0),
        activeSubscriptions: Number(activeSubsResult[0]?.count || 0)
      },
      popularProducts,
      recentUsers,
      monthlyGrowth
    });
  } catch (error) {
    console.error('Get analytics error:', error);
    res.status(500).json({ error: 'Failed to get analytics' });
  }
});

// Get all users
router.get('/users', async (req, res) => {
  try {
    const { page = '1', limit = '20', search } = req.query;
    
    const pageNum = parseInt(page as string);
    const limitNum = parseInt(limit as string);
    const offset = (pageNum - 1) * limitNum;

    const allUsers = await db.query.users.findMany({
      where: search 
        ? sql`${users.name} ILIKE ${`%${search}%`} OR ${users.email} ILIKE ${`%${search}%`}`
        : undefined,
      columns: {
        id: true,
        email: true,
        name: true,
        avatarUrl: true,
        role: true,
        createdAt: true
      },
      orderBy: (users, { desc }) => [desc(users.createdAt)],
      limit: limitNum,
      offset
    });

    const countResult = await db.select({ count: db.fn.count() }).from(users);
    const total = Number(countResult[0]?.count || 0);

    res.json({
      users: allUsers,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        pages: Math.ceil(total / limitNum)
      }
    });
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({ error: 'Failed to get users' });
  }
});

// Update user role
router.patch('/users/:id/role', async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { role } = req.body;

    if (!['admin', 'premium', 'free'].includes(role)) {
      return res.status(400).json({ error: 'Invalid role' });
    }

    const [updated] = await db.update(users)
      .set({ role, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();

    res.json({
      message: 'User role updated',
      user: updated
    });
  } catch (error) {
    console.error('Update user role error:', error);
    res.status(500).json({ error: 'Failed to update user role' });
  }
});

// Get pending products/uploads
router.get('/pending-products', async (req, res) => {
  try {
    const pendingProducts = await db.query.products.findMany({
      where: eq(products.status, 'pending'),
      with: {
        author: {
          columns: {
            id: true,
            name: true,
            email: true
          }
        }
      },
      orderBy: (products, { desc }) => [desc(products.createdAt)]
    });

    res.json(pendingProducts);
  } catch (error) {
    console.error('Get pending products error:', error);
    res.status(500).json({ error: 'Failed to get pending products' });
  }
});

// Approve/reject product
router.patch('/products/:id/status', async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!['published', 'rejected'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }

    const [updated] = await db.update(products)
      .set({ status, updatedAt: new Date() })
      .where(eq(products.id, id))
      .returning();

    res.json({
      message: `Product ${status}`,
      product: updated
    });
  } catch (error) {
    console.error('Update product status error:', error);
    res.status(500).json({ error: 'Failed to update product status' });
  }
});

// Delete user
router.delete('/users/:id', async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    // Prevent deleting yourself
    if (id === req.user!.id) {
      return res.status(400).json({ error: 'Cannot delete yourself' });
    }

    await db.delete(users).where(eq(users.id, id));

    res.json({ message: 'User deleted' });
  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({ error: 'Failed to delete user' });
  }
});

export { router as adminRouter };
