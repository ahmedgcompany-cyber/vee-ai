import { Router } from 'express';
import sgMail from '@sendgrid/mail';
import { authMiddleware, AuthRequest } from '../middleware/auth';

const router = Router();

// Initialize SendGrid
sgMail.setApiKey(process.env.SENDGRID_API_KEY || '');

const FROM_EMAIL = process.env.FROM_EMAIL || 'noreply@vee.ai';

// Send welcome email
router.post('/welcome', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { email, name } = req.body;

    const msg = {
      to: email,
      from: FROM_EMAIL,
      subject: 'Welcome to VEE.ai!',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #A67DFF;">Welcome to VEE.ai, ${name}!</h1>
          <p>We're excited to have you join our community of creators and innovators.</p>
          <p>With VEE.ai, you can:</p>
          <ul>
            <li>Upload and share your apps, games, and AI agents</li>
            <li>Discover amazing projects from other creators</li>
            <li>Build your audience and monetize your work</li>
          </ul>
          <a href="${process.env.FRONTEND_URL}/dashboard" 
             style="display: inline-block; background: #A67DFF; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; margin-top: 20px;">
            Go to Dashboard
          </a>
          <p style="margin-top: 30px; color: #666; font-size: 12px;">
            If you didn't create this account, please ignore this email.
          </p>
        </div>
      `
    };

    await sgMail.send(msg);

    res.json({ message: 'Welcome email sent' });
  } catch (error) {
    console.error('Send welcome email error:', error);
    res.status(500).json({ error: 'Failed to send welcome email' });
  }
});

// Send purchase confirmation
router.post('/purchase-confirmation', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { email, productName, price } = req.body;

    const msg = {
      to: email,
      from: FROM_EMAIL,
      subject: `Purchase Confirmation: ${productName}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #A67DFF;">Thank you for your purchase!</h1>
          <p>You've successfully purchased <strong>${productName}</strong>.</p>
          <div style="background: #f5f5f5; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0;"><strong>Product:</strong> ${productName}</p>
            <p style="margin: 10px 0 0;"><strong>Price:</strong> $${price}</p>
          </div>
          <p>You can download your purchase from your dashboard.</p>
          <a href="${process.env.FRONTEND_URL}/dashboard" 
             style="display: inline-block; background: #A67DFF; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; margin-top: 20px;">
            View My Purchases
          </a>
        </div>
      `
    };

    await sgMail.send(msg);

    res.json({ message: 'Purchase confirmation sent' });
  } catch (error) {
    console.error('Send purchase confirmation error:', error);
    res.status(500).json({ error: 'Failed to send purchase confirmation' });
  }
});

// Send upload approved notification
router.post('/upload-approved', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { email, productName } = req.body;

    const msg = {
      to: email,
      from: FROM_EMAIL,
      subject: `Your upload "${productName}" has been approved!`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #A67DFF;">Congratulations! 🎉</h1>
          <p>Your upload <strong>${productName}</strong> has been approved and is now live on VEE.ai!</p>
          <p>Your creation is now available for the world to discover and enjoy.</p>
          <a href="${process.env.FRONTEND_URL}/product/${productName.toLowerCase().replace(/\s+/g, '-')}" 
             style="display: inline-block; background: #A67DFF; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; margin-top: 20px;">
            View Your Product
          </a>
        </div>
      `
    };

    await sgMail.send(msg);

    res.json({ message: 'Approval notification sent' });
  } catch (error) {
    console.error('Send approval notification error:', error);
    res.status(500).json({ error: 'Failed to send approval notification' });
  }
});

// Generic email sender (admin only)
router.post('/send', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { to, subject, html } = req.body;

    const msg = {
      to,
      from: FROM_EMAIL,
      subject,
      html
    };

    await sgMail.send(msg);

    res.json({ message: 'Email sent' });
  } catch (error) {
    console.error('Send email error:', error);
    res.status(500).json({ error: 'Failed to send email' });
  }
});

export { router as emailRouter };
