import { Router } from 'express';
import Stripe from 'stripe';
import { eq } from 'drizzle-orm';
import { db } from '../utils/db';
import { products, purchases, subscriptions, users } from '../models/schema';
import { authMiddleware, AuthRequest } from '../middleware/auth';

const router = Router();

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2023-10-16'
});

// Create payment intent for one-time purchase
router.post('/create-payment-intent', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { productId } = req.body;

    // Get product
    const product = await db.query.products.findFirst({
      where: eq(products.id, productId)
    });

    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    if (product.type !== 'paid' || !product.price) {
      return res.status(400).json({ error: 'Product is not available for purchase' });
    }

    // Get or create Stripe customer
    let user = await db.query.users.findFirst({
      where: eq(users.id, req.user!.id)
    });

    let customerId = user?.stripeCustomerId;

    if (!customerId) {
      const customer = await stripe.customers.create({
        email: req.user!.email,
        name: req.user!.name
      });
      customerId = customer.id;

      // Save customer ID
      await db.update(users)
        .set({ stripeCustomerId: customerId })
        .where(eq(users.id, req.user!.id));
    }

    // Create payment intent
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(parseFloat(product.price) * 100), // Convert to cents
      currency: 'usd',
      customer: customerId,
      metadata: {
        productId,
        userId: req.user!.id
      }
    });

    res.json({
      clientSecret: paymentIntent.client_secret
    });
  } catch (error) {
    console.error('Create payment intent error:', error);
    res.status(500).json({ error: 'Failed to create payment intent' });
  }
});

// Create subscription
router.post('/create-subscription', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { productId, interval = 'monthly' } = req.body;

    // Get product
    const product = await db.query.products.findFirst({
      where: eq(products.id, productId)
    });

    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    if (product.type !== 'subscription') {
      return res.status(400).json({ error: 'Product is not a subscription' });
    }

    // Get or create Stripe customer
    let user = await db.query.users.findFirst({
      where: eq(users.id, req.user!.id)
    });

    let customerId = user?.stripeCustomerId;

    if (!customerId) {
      const customer = await stripe.customers.create({
        email: req.user!.email,
        name: req.user!.name
      });
      customerId = customer.id;

      await db.update(users)
        .set({ stripeCustomerId: customerId })
        .where(eq(users.id, req.user!.id));
    }

    // Create price if not exists (in production, you'd store the Stripe price ID)
    const priceAmount = interval === 'monthly' 
      ? product.subscriptionMonthly 
      : product.subscriptionYearly;

    const stripePrice = await stripe.prices.create({
      unit_amount: Math.round(parseFloat(priceAmount || '0') * 100),
      currency: 'usd',
      recurring: {
        interval: interval === 'monthly' ? 'month' : 'year'
      },
      product_data: {
        name: product.title
      }
    });

    // Create subscription
    const subscription = await stripe.subscriptions.create({
      customer: customerId,
      items: [{ price: stripePrice.id }],
      payment_behavior: 'default_incomplete',
      expand: ['latest_invoice.payment_intent']
    });

    // Save subscription to database
    await db.insert(subscriptions).values({
      userId: req.user!.id,
      productId,
      planId: stripePrice.id,
      planName: product.title,
      status: 'active',
      startDate: new Date(),
      endDate: new Date(Date.now() + (interval === 'monthly' ? 30 : 365) * 24 * 60 * 60 * 1000),
      price: parseFloat(priceAmount || '0'),
      interval: interval as 'monthly' | 'yearly',
      stripeSubscriptionId: subscription.id
    });

    res.json({
      subscriptionId: subscription.id,
      clientSecret: (subscription.latest_invoice as any).payment_intent.client_secret
    });
  } catch (error) {
    console.error('Create subscription error:', error);
    res.status(500).json({ error: 'Failed to create subscription' });
  }
});

// Cancel subscription
router.post('/cancel-subscription', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { subscriptionId } = req.body;

    // Cancel in Stripe
    await stripe.subscriptions.cancel(subscriptionId);

    // Update in database
    await db.update(subscriptions)
      .set({ status: 'cancelled' })
      .where(eq(subscriptions.stripeSubscriptionId, subscriptionId));

    res.json({ message: 'Subscription cancelled' });
  } catch (error) {
    console.error('Cancel subscription error:', error);
    res.status(500).json({ error: 'Failed to cancel subscription' });
  }
});

// Stripe webhook
router.post('/webhook', async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!sig || !endpointSecret) {
    return res.status(400).json({ error: 'Missing signature or endpoint secret' });
  }

  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
  } catch (err: any) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // Handle events
  switch (event.type) {
    case 'payment_intent.succeeded': {
      const paymentIntent = event.data.object as Stripe.PaymentIntent;
      
      // Record purchase
      if (paymentIntent.metadata.productId && paymentIntent.metadata.userId) {
        const product = await db.query.products.findFirst({
          where: eq(products.id, paymentIntent.metadata.productId)
        });

        if (product) {
          await db.insert(purchases).values({
            userId: paymentIntent.metadata.userId,
            productId: paymentIntent.metadata.productId,
            price: (paymentIntent.amount / 100).toString(),
            status: 'completed',
            stripePaymentIntentId: paymentIntent.id
          });
        }
      }
      break;
    }

    case 'invoice.payment_succeeded': {
      const invoice = event.data.object as Stripe.Invoice;
      // Handle subscription renewal
      break;
    }

    case 'customer.subscription.deleted': {
      const subscription = event.data.object as Stripe.Subscription;
      // Update subscription status
      await db.update(subscriptions)
        .set({ status: 'expired' })
        .where(eq(subscriptions.stripeSubscriptionId, subscription.id));
      break;
    }

    default:
      console.log(`Unhandled event type: ${event.type}`);
  }

  res.json({ received: true });
});

// Get user's purchases
router.get('/purchases', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userPurchases = await db.query.purchases.findMany({
      where: eq(purchases.userId, req.user!.id),
      with: {
        product: true
      },
      orderBy: (purchases, { desc }) => [desc(purchases.createdAt)]
    });

    res.json(userPurchases);
  } catch (error) {
    console.error('Get purchases error:', error);
    res.status(500).json({ error: 'Failed to get purchases' });
  }
});

// Get user's subscriptions
router.get('/subscriptions', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userSubscriptions = await db.query.subscriptions.findMany({
      where: eq(subscriptions.userId, req.user!.id),
      with: {
        product: true
      },
      orderBy: (subscriptions, { desc }) => [desc(subscriptions.createdAt)]
    });

    res.json(userSubscriptions);
  } catch (error) {
    console.error('Get subscriptions error:', error);
    res.status(500).json({ error: 'Failed to get subscriptions' });
  }
});

export { router as paymentsRouter };
