import { 
  pgTable, 
  uuid, 
  varchar, 
  text, 
  timestamp, 
  decimal, 
  integer, 
  boolean,
  jsonb,
  pgEnum
} from 'drizzle-orm/pg-core';

// Enums
export const userRoleEnum = pgEnum('user_role', ['admin', 'premium', 'free']);
export const productTypeEnum = pgEnum('product_type', ['free', 'paid', 'subscription', 'trial']);
export const productCategoryEnum = pgEnum('product_category', [
  'ai-tools', 
  'saas-apps', 
  'games', 
  'experiments', 
  'design-systems',
  'productivity',
  'developer-tools'
]);
export const productStatusEnum = pgEnum('product_status', ['pending', 'published', 'rejected']);
export const subscriptionStatusEnum = pgEnum('subscription_status', ['active', 'cancelled', 'expired']);
export const purchaseStatusEnum = pgEnum('purchase_status', ['completed', 'pending', 'refunded']);

// Users table
export const users = pgTable('users', {
  id: uuid('id').primaryKey().defaultRandom(),
  email: varchar('email', { length: 255 }).notNull().unique(),
  passwordHash: varchar('password_hash', { length: 255 }).notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  avatarUrl: text('avatar_url'),
  role: userRoleEnum('role').default('free').notNull(),
  stripeCustomerId: varchar('stripe_customer_id', { length: 255 }),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Products table
export const products = pgTable('products', {
  id: uuid('id').primaryKey().defaultRandom(),
  title: varchar('title', { length: 255 }).notNull(),
  description: text('description').notNull(),
  shortDescription: text('short_description'),
  category: productCategoryEnum('category').notNull(),
  type: productTypeEnum('type').notNull(),
  price: decimal('price', { precision: 10, scale: 2 }),
  subscriptionMonthly: decimal('subscription_monthly', { precision: 10, scale: 2 }),
  subscriptionYearly: decimal('subscription_yearly', { precision: 10, scale: 2 }),
  trialDays: integer('trial_days'),
  images: jsonb('images').$type<string[]>().default([]),
  videoUrl: text('video_url'),
  features: jsonb('features').$type<string[]>().default([]),
  techStack: jsonb('tech_stack').$type<string[]>().default([]),
  tags: jsonb('tags').$type<string[]>().default([]),
  version: varchar('version', { length: 20 }),
  fileSize: varchar('file_size', { length: 20 }),
  fileUrl: text('file_url'),
  downloads: integer('downloads').default(0),
  rating: decimal('rating', { precision: 2, scale: 1 }).default('5.0'),
  authorId: uuid('author_id').references(() => users.id),
  status: productStatusEnum('status').default('pending').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Reviews table
export const reviews = pgTable('reviews', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id).notNull(),
  productId: uuid('product_id').references(() => products.id).notNull(),
  rating: integer('rating').notNull(),
  comment: text('comment'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Purchases table
export const purchases = pgTable('purchases', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id).notNull(),
  productId: uuid('product_id').references(() => products.id).notNull(),
  price: decimal('price', { precision: 10, scale: 2 }).notNull(),
  status: purchaseStatusEnum('status').default('completed').notNull(),
  stripePaymentIntentId: varchar('stripe_payment_intent_id', { length: 255 }),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Subscriptions table
export const subscriptions = pgTable('subscriptions', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id).notNull(),
  productId: uuid('product_id').references(() => products.id),
  planId: varchar('plan_id', { length: 50 }),
  planName: varchar('plan_name', { length: 100 }),
  status: subscriptionStatusEnum('status').notNull(),
  startDate: timestamp('start_date'),
  endDate: timestamp('end_date'),
  price: decimal('price', { precision: 10, scale: 2 }),
  interval: varchar('interval', { length: 20 }),
  stripeSubscriptionId: varchar('stripe_subscription_id', { length: 255 }),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Downloads table
export const downloads = pgTable('downloads', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id).notNull(),
  productId: uuid('product_id').references(() => products.id).notNull(),
  version: varchar('version', { length: 20 }),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Favorites table
export const favorites = pgTable('favorites', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id).notNull(),
  productId: uuid('product_id').references(() => products.id).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Blog posts table
export const blogPosts = pgTable('blog_posts', {
  id: uuid('id').primaryKey().defaultRandom(),
  title: varchar('title', { length: 255 }).notNull(),
  excerpt: text('excerpt'),
  content: text('content').notNull(),
  authorId: uuid('author_id').references(() => users.id).notNull(),
  coverImage: text('cover_image'),
  tags: jsonb('tags').$type<string[]>().default([]),
  publishedAt: timestamp('published_at'),
  readTime: integer('read_time'),
  likes: integer('likes').default(0),
  comments: integer('comments').default(0),
  status: productStatusEnum('status').default('pending').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Videos table
export const videos = pgTable('videos', {
  id: uuid('id').primaryKey().defaultRandom(),
  title: varchar('title', { length: 255 }).notNull(),
  description: text('description'),
  thumbnail: text('thumbnail'),
  videoUrl: text('video_url').notNull(),
  duration: varchar('duration', { length: 10 }),
  views: integer('views').default(0),
  likes: integer('likes').default(0),
  authorId: uuid('author_id').references(() => users.id).notNull(),
  status: productStatusEnum('status').default('pending').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Type exports
export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type Product = typeof products.$inferSelect;
export type NewProduct = typeof products.$inferInsert;
export type Review = typeof reviews.$inferSelect;
export type Purchase = typeof purchases.$inferSelect;
export type Subscription = typeof subscriptions.$inferSelect;
export type Download = typeof downloads.$inferSelect;
export type BlogPost = typeof blogPosts.$inferSelect;
export type Video = typeof videos.$inferSelect;
