# 🚀 Vercel Deployment Guide - Step by Step

## Your Goal: Get a FREE Permanent URL (vee-ai.vercel.app)

---

## 📋 Prerequisites

Before we start, you need:
1. **GitHub Account** - https://github.com/signup
2. **Vercel Account** - https://vercel.com/signup (use "Continue with GitHub")

---

## 🎯 Overview of Steps

1. Push code to GitHub (5 min)
2. Connect GitHub to Vercel (2 min)
3. Configure and deploy (3 min)
4. Get your permanent URL! 🎉

**Total Time: ~10 minutes**

---

## STEP 1: Push Code to GitHub

### 1.1 Create a GitHub Repository

1. Go to https://github.com/new
2. **Repository name**: `vee-ai`
3. **Description**: `VEE.ai - Creator platform for apps, games, and AI agents`
4. Make it **Public** (required for free Vercel)
5. **DO NOT** initialize with README (we have our own)
6. Click **Create repository**

You'll see a page like this:
```
https://github.com/YOUR_USERNAME/vee-ai
```

**Copy this URL** - you'll need it!

---

### 1.2 Push Your Code

Open terminal/command prompt and run these commands:

```bash
# Navigate to your project folder
cd /mnt/okcomputer/output

# Initialize git
git init

# Add all files
git add .

# Commit with a message
git commit -m "Initial commit - VEE.ai platform by Ahmed M T Alghoul"

# Connect to your GitHub repo (replace YOUR_USERNAME with your actual GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/vee-ai.git

# Push to GitHub
git push -u origin main
```

**If you get an error about authentication**, you may need to:
- Use a Personal Access Token instead of password
- Or use GitHub Desktop app

---

### 1.3 Verify Your Code is on GitHub

1. Go to https://github.com/YOUR_USERNAME/vee-ai
2. You should see all your files:
   - `app/` folder
   - `vee-ai-backend/` folder
   - `README.md`
   - etc.

✅ **Step 1 Complete!**

---

## STEP 2: Connect to Vercel

### 2.1 Sign Up / Log In

1. Go to https://vercel.com
2. Click **"Sign Up"**
3. Choose **"Continue with GitHub"**
4. Authorize Vercel to access your GitHub

---

### 2.2 Create New Project

1. On Vercel dashboard, click **"Add New Project"**
2. You'll see a list of your GitHub repositories
3. Find and click **"Import"** next to `vee-ai`

---

## STEP 3: Configure Project

### 3.1 Project Settings

You'll see a configuration form. Fill it like this:

| Setting | Value |
|---------|-------|
| **Project Name** | `vee-ai` (or whatever you want) |
| **Framework Preset** | `Vite` |
| **Root Directory** | `app` |

---

### 3.2 Build Settings

Click **"Build and Output Settings"** to expand:

| Setting | Value |
|---------|-------|
| **Build Command** | `npm run build` |
| **Output Directory** | `dist` |
| **Install Command** | `npm install` |

Leave other settings as default.

---

### 3.3 Environment Variables (IMPORTANT!)

Click **"Environment Variables"** to expand:

Add this variable:

```
Key: VITE_API_URL
Value: https://your-backend-url.railway.app
```

**For now**, use a placeholder:
```
Key: VITE_API_URL
Value: http://localhost:3001
```

You'll update this after deploying your backend.

---

### 3.4 Deploy!

Click the big **"Deploy"** button!

Vercel will:
1. Clone your repository
2. Install dependencies (`npm install`)
3. Build your project (`npm run build`)
4. Deploy to global CDN

This takes 1-2 minutes.

---

## STEP 4: Get Your URL! 🎉

### 4.1 Your Permanent URL

Once deployment is complete, you'll see:

```
🎉 Congratulations!
Your project is live at:
https://vee-ai.vercel.app
```

**This URL is:**
- ✅ **FREE forever**
- ✅ **Never expires**
- ✅ **HTTPS enabled**
- ✅ **Global CDN (fast worldwide)**

---

### 4.2 Test Your Website

1. Click the URL: `https://vee-ai.vercel.app`
2. Your VEE.ai website should load!
3. Test navigation, animations, etc.

---

### 4.3 What You'll See

Your website includes:
- VEE.ai logo and branding
- Animated hero section
- Project showcase
- Your name: **AHMED M T ALGHOUL**
- User dashboard (click avatar)
- Admin panel (bottom right)
- Upload system

---

## 🎨 Customize Your Domain (Optional)

### Use a Custom Domain

1. In Vercel dashboard, go to your project
2. Click **"Settings"** tab
3. Click **"Domains"** in left sidebar
4. Enter your domain (e.g., `vee.ai`)
5. Follow DNS configuration instructions

**Recommended registrars:**
- Namecheap: https://namecheap.com (~$10-15/year)
- Cloudflare: https://cloudflare.com

---

## 🔄 Update Your Website

When you make changes:

```bash
# Make your changes
cd /mnt/okcomputer/output/app
# Edit files...

# Build locally to test
npm run build

# Commit and push
git add .
git commit -m "Your update message"
git push
```

**Vercel automatically redeploys** when you push to GitHub!

---

## 🆘 Troubleshooting

### Issue: "Build Failed"

**Solution:**
1. Check Vercel logs (click on the failed deployment)
2. Common fixes:
   - Make sure `Root Directory` is set to `app`
   - Make sure `Framework Preset` is `Vite`

### Issue: "Page Not Found" or 404

**Solution:**
1. Check that `dist` folder exists in your `app` folder
2. Verify `Output Directory` is set to `dist`

### Issue: "Cannot find module"

**Solution:**
1. Make sure `package.json` is in the `app` folder
2. Try redeploying with "Redeploy" button

### Issue: Git push fails

**Solution:**
```bash
# If you get authentication error, use token:
git remote set-url origin https://YOUR_USERNAME:TOKEN@github.com/YOUR_USERNAME/vee-ai.git

# Or use GitHub Desktop app instead
```

---

## 📊 What You Get (FREE!)

| Feature | Included |
|---------|----------|
| **Hosting** | ✅ Unlimited |
| **Bandwidth** | ✅ 100GB/month |
| **Builds** | ✅ 6000 minutes/month |
| **SSL/HTTPS** | ✅ Automatic |
| **CDN** | ✅ Global |
| **Custom Domain** | ✅ Supported |
| **Team Members** | ✅ Unlimited |

---

## ✅ Success Checklist

- [ ] GitHub repository created
- [ ] Code pushed to GitHub
- [ ] Vercel account created
- [ ] Project imported to Vercel
- [ ] Root Directory set to `app`
- [ ] Framework set to `Vite`
- [ ] Deployed successfully
- [ ] Website loads at `https://vee-ai.vercel.app`

---

## 🎯 Next Steps

After Vercel deployment:

1. **Deploy Backend** → Follow Railway guide
2. **Set up Database** → Use Supabase
3. **Configure Services** → AWS, Stripe, SendGrid
4. **Update Environment Variables** → Connect frontend to backend

See `SETUP_GUIDE.md` for complete backend deployment!

---

## 📞 Need Help?

- **Vercel Docs**: https://vercel.com/docs
- **Vercel Discord**: https://vercel.com/discord
- **GitHub Help**: https://docs.github.com

---

**Your permanent URL will be: `https://vee-ai.vercel.app`** 🚀

**Built with ❤️ by AHMED M T ALGHOUL**
