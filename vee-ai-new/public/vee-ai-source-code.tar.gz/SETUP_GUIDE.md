# VEE.ai - Complete Setup Guide

This guide will walk you through deploying VEE.ai with **permanent free hosting** and all backend services.

---

## 🎯 What We're Building

| Service | Provider | Cost | Status |
|---------|----------|------|--------|
| **Frontend** | Vercel | **FREE Forever** | ✅ |
| **Backend** | Railway | **FREE** ($5 credit/month) | ✅ |
| **Database** | Supabase | **FREE Tier** | ✅ |
| **File Storage** | AWS S3 | **~$1-5/month** | ✅ |
| **Payments** | Stripe | **Pay per transaction** | ✅ |
| **Email** | SendGrid | **FREE** (100/day) | ✅ |
| **Domain** | Namecheap | **$10-15/year** | Optional |

---

## 📋 Prerequisites

1. **GitHub Account** - https://github.com
2. **Vercel Account** - https://vercel.com (Sign up with GitHub)
3. **Railway Account** - https://railway.app (Sign up with GitHub)
4. **Supabase Account** - https://supabase.com (Sign up with GitHub)
5. **AWS Account** - https://aws.amazon.com
6. **Stripe Account** - https://stripe.com
7. **SendGrid Account** - https://sendgrid.com

---

## 🚀 Step 1: Push Code to GitHub

### 1.1 Create a New GitHub Repository

1. Go to https://github.com/new
2. Name it `vee-ai`
3. Make it **Public** (for free Vercel deployment)
4. Click **Create repository**

### 1.2 Upload Your Code

```bash
# Open terminal in the project folder
cd /mnt/okcomputer/output

# Initialize git
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit - VEE.ai platform"

# Add remote (replace with your repo URL)
git remote add origin https://github.com/YOUR_USERNAME/vee-ai.git

# Push
git push -u origin main
```

---

## 🌐 Step 2: Deploy Frontend to Vercel (FREE Forever)

### 2.1 Connect to Vercel

1. Go to https://vercel.com
2. Click **Add New Project**
3. Import your `vee-ai` GitHub repository
4. Configure:
   - **Framework Preset**: Vite
   - **Root Directory**: `app`
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`

5. Click **Deploy**

### 2.2 Get Your Frontend URL

After deployment, Vercel will give you a URL like:
```
https://vee-ai.vercel.app
```

**Save this URL** - you'll need it for the backend.

---

## 🖥️ Step 3: Set Up Supabase Database (FREE)

### 3.1 Create Project

1. Go to https://supabase.com
2. Click **New Project**
3. Name: `vee-ai-db`
4. Choose region closest to your users
5. Click **Create new project**

### 3.2 Get Database URL

1. In your project, go to **Settings** → **Database**
2. Under **Connection string**, select **URI**
3. Copy the connection string
4. **Replace** `[YOUR-PASSWORD]` with your actual database password

Example:
```
postgresql://postgres:YourPassword123@db.abc123xyz.supabase.co:5432/postgres
```

---

## 🖥️ Step 4: Deploy Backend to Railway (FREE)

### 4.1 Create Project

1. Go to https://railway.app
2. Click **New Project**
3. Select **Deploy from GitHub repo**
4. Choose your `vee-ai` repository

### 4.2 Configure Deployment

1. Railway will auto-detect it's a Node.js project
2. Add environment variables (click **Variables** tab):

```
NODE_ENV=production
PORT=3001
FRONTEND_URL=https://vee-ai.vercel.app
DATABASE_URL=your-supabase-connection-string
JWT_SECRET=generate-a-random-string-here
```

**Generate JWT Secret:**
```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

### 4.3 Deploy

1. Railway will automatically deploy
2. Get your backend URL (e.g., `https://vee-ai-production.up.railway.app`)
3. **Save this URL**

### 4.4 Run Database Migrations

In Railway, go to your project → **Shell** tab:

```bash
cd vee-ai-backend
npm install
npm run db:migrate
```

---

## 📦 Step 5: Set Up AWS S3 File Storage

### 5.1 Create S3 Bucket

1. Go to https://s3.console.aws.amazon.com
2. Click **Create bucket**
3. Bucket name: `vee-ai-uploads`
4. Region: Choose same as your backend
5. **Uncheck** "Block all public access"
6. Check "I acknowledge..."
7. Click **Create bucket**

### 5.2 Create IAM User

1. Go to https://console.aws.amazon.com/iam
2. Click **Users** → **Create user**
3. User name: `vee-ai-s3-user`
4. Click **Next**
5. Permissions: **Attach policies directly**
6. Search and select: `AmazonS3FullAccess`
7. Click **Next** → **Create user**

### 5.3 Get Access Keys

1. Click on your new user
2. Go to **Security credentials** tab
3. Click **Create access key**
4. Select **Application running outside AWS**
5. Click **Next** → **Create access key**
6. **SAVE BOTH KEYS** (you won't see them again!)

### 5.4 Add to Railway Environment Variables

Go back to Railway, add these variables:

```
AWS_ACCESS_KEY_ID=AKIA...
AWS_SECRET_ACCESS_KEY=...
AWS_REGION=us-east-1
S3_BUCKET=vee-ai-uploads
```

---

## 💳 Step 6: Set Up Stripe Payments

### 6.1 Get API Keys

1. Go to https://dashboard.stripe.com
2. Click **Developers** → **API keys**
3. Copy **Secret key** (starts with `sk_test_` for testing)
4. Copy **Publishable key** (starts with `pk_test_`)

### 6.2 Set Up Webhook

1. Go to **Developers** → **Webhooks**
2. Click **Add endpoint**
3. Endpoint URL: `https://your-railway-url/api/payments/webhook`
4. Select events:
   - `payment_intent.succeeded`
   - `invoice.payment_succeeded`
   - `customer.subscription.deleted`
5. Click **Add endpoint**
6. Copy the **Signing secret** (starts with `whsec_`)

### 6.3 Add to Railway

```
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
```

---

## 📧 Step 7: Set Up SendGrid Email

### 7.1 Create API Key

1. Go to https://app.sendgrid.com
2. Go to **Settings** → **API Keys**
3. Click **Create API Key**
4. Name: `vee-ai-email`
5. Access: **Full Access**
6. Click **Create & View**
7. **SAVE THE KEY** (starts with `SG.`)

### 7.2 Verify Sender

1. Go to **Settings** → **Sender Authentication**
2. Click **Verify Single Sender**
3. Fill in your details
4. Verify your email

### 7.3 Add to Railway

```
SENDGRID_API_KEY=SG.xxx
FROM_EMAIL=your-verified-email@example.com
```

---

## 🔗 Step 8: Connect Frontend to Backend

### 8.1 Update Frontend Environment Variables

In Vercel dashboard:
1. Go to your project → **Settings** → **Environment Variables**
2. Add:

```
VITE_API_URL=https://your-railway-backend-url
```

### 8.2 Redeploy Frontend

Vercel will automatically redeploy with the new environment variable.

---

## 🌐 Step 9: Custom Domain (Optional but Recommended)

### 9.1 Buy Domain

1. Go to https://namecheap.com
2. Search for `vee.ai` or `getvee.ai`
3. Purchase your domain (~$10-15/year)

### 9.2 Connect to Vercel

1. In Vercel dashboard, go to **Settings** → **Domains**
2. Add your domain: `vee.ai`
3. Follow the DNS configuration instructions
4. In Namecheap, update DNS records as instructed

### 9.3 Update Backend CORS

In Railway, update:
```
FRONTEND_URL=https://vee.ai
```

---

## ✅ Step 10: Test Everything

### 10.1 Test Backend Health

```bash
curl https://your-railway-url/health
```

Should return: `{"status":"ok"}`

### 10.2 Test Registration

```bash
curl -X POST https://your-railway-url/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123","name":"Test User"}'
```

### 10.3 Test Frontend

1. Visit your Vercel URL
2. Try uploading a file
3. Check that it appears in S3 bucket

---

## 📊 Monitoring & Maintenance

### Railway Dashboard
- Monitor server logs
- View resource usage
- Restart if needed

### Supabase Dashboard
- Monitor database queries
- View connection pool
- Check storage usage

### AWS S3
- Monitor storage costs
- Set up lifecycle rules for old files

### Stripe Dashboard
- Monitor payments
- View revenue
- Manage subscriptions

---

## 💰 Expected Costs

| Service | Monthly Cost |
|---------|-------------|
| Vercel | **$0** (Free tier) |
| Railway | **$0** (Free $5 credit) |
| Supabase | **$0** (Free tier) |
| AWS S3 | **$1-5** (depending on usage) |
| Stripe | **2.9% + 30¢ per transaction** |
| SendGrid | **$0** (Free 100 emails/day) |
| Domain | **~$1/month** (if purchased) |

**Total: $2-7/month for a fully functional platform!**

---

## 🆘 Troubleshooting

### Backend won't start
- Check Railway logs
- Verify all environment variables are set
- Ensure DATABASE_URL is correct

### Database connection fails
- Check Supabase connection string
- Ensure password is correct
- Check if IP is allowed (Supabase → Database → Network)

### File uploads fail
- Verify AWS credentials
- Check S3 bucket permissions
- Ensure CORS is configured on bucket

### Payments don't work
- Verify Stripe keys
- Check webhook URL is correct
- Test with Stripe test cards

---

## 🎉 You're Done!

Your VEE.ai platform is now:
- ✅ **Live** on a permanent URL
- ✅ **Free** to run (mostly)
- ✅ **Scalable** as you grow
- ✅ **Secure** with proper authentication
- ✅ **Full-featured** with payments, uploads, and more

**Share your URL:** `https://vee-ai.vercel.app` or your custom domain!

---

## 📞 Need Help?

- **Vercel Docs**: https://vercel.com/docs
- **Railway Docs**: https://docs.railway.app
- **Supabase Docs**: https://supabase.com/docs
- **Stripe Docs**: https://stripe.com/docs

---

**Built with ❤️ by AHMED M T ALGHOUL**
